package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class BooleanException extends Exception {
    public BooleanException(String mensagem) {
        super(mensagem);
    }
}
