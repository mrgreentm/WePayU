package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class EmpregadoNaoHoristaException extends Exception {

    public EmpregadoNaoHoristaException(String mensagem) {
        super(mensagem);
    }
}
