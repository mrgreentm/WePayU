package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class EmpregadoNaoEncontradoPeloNomeException extends Exception {

    public EmpregadoNaoEncontradoPeloNomeException(String mensagem) {
        super(mensagem);
    }
}
