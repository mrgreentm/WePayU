package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class AtributoInexistenteException extends Exception {
    public AtributoInexistenteException(String mensagem) {
        super(mensagem);
    }
}
