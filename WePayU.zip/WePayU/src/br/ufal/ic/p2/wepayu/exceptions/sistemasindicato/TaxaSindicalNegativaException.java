package br.ufal.ic.p2.wepayu.exceptions.sistemasindicato;

public class TaxaSindicalNegativaException extends Exception {
    public TaxaSindicalNegativaException(String mensagem) {
        super(mensagem);
    }
}
