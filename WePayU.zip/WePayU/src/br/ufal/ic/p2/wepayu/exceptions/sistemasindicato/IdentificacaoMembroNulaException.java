package br.ufal.ic.p2.wepayu.exceptions.sistemasindicato;

public class IdentificacaoMembroNulaException extends Exception {
    public IdentificacaoMembroNulaException(String mensagem) {
        super(mensagem);
    }
}
