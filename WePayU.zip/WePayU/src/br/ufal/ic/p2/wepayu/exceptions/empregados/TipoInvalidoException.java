package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class TipoInvalidoException extends Exception {
    public TipoInvalidoException(String mensagem) {
        super(mensagem);
    }
}
