package br.ufal.ic.p2.wepayu.exceptions.sistemafolha;

public class SistemaFolhaException extends Exception {
    public SistemaFolhaException(String mensagem) {
        super(mensagem);
    }
}
