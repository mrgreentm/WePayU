package br.ufal.ic.p2.wepayu.exceptions.sistemasindicato;

public class SistemaTaxasSindicaisException extends Exception {
    public SistemaTaxasSindicaisException(String mensagem) {
        super(mensagem);
    }
}
