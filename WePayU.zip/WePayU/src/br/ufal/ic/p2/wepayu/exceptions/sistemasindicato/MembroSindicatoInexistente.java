package br.ufal.ic.p2.wepayu.exceptions.sistemasindicato;

public class MembroSindicatoInexistente extends Exception {

    public MembroSindicatoInexistente(String mensagem) {
        super(mensagem);
    }
}
