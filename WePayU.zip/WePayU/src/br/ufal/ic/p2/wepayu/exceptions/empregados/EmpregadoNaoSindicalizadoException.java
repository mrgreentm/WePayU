package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class EmpregadoNaoSindicalizadoException extends Exception {

    public EmpregadoNaoSindicalizadoException(String mensagem) {
        super(mensagem);
    }
}
