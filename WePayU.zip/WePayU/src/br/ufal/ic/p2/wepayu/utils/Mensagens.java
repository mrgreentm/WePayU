package br.ufal.ic.p2.wepayu.utils;

public class Mensagens {
    public static String empregadoNaoComissionado = "Empregado nao eh comissionado.";
    public static String empregadoNaoHorista = "Empregado nao eh horista.";
    public static String empregadoNaoEncontradoPeloNome = "Nao ha empregado com esse nome.";
    public static String empregadoNaoExiste = "Empregado nao existe.";
    public static String metodoPagamentoInvalido = "Metodo de pagamento invalido.";
    public static String atributoInexistente = "Atributo nao existe.";
    public static String valorNaoBooleano = "Valor deve ser true ou false.";
    public static String valorNegativo = "Valor deve ser positivo.";
    public static String tipoInvalido = "Tipo invalido.";
    public static String taxaSindicalNaoNumerica = "Taxa sindical deve ser numerica.";
    public static String taxaSindicalNegativa = "Taxa sindical deve ser nao-negativa.";
    public static String empregadoDuplicadoSindicato = "Ha outro empregado com esta identificacao de sindicato";
    public static String membroSindicatoInexistente = "Membro nao existe.";
    public static String empregadoNaoSindicalizado = "Empregado nao eh sindicalizado.";
    public static String identificacaoNulaMembro = "Identificacao do membro nao pode ser nula.";
    public static String dataInvalida = "Data invalida.";
    public static String dataInicialInvalida = "Data inicial invalida.";
    public static String dataFinalInvalida = "Data final invalida.";
    public static String horasNegativas = "Horas devem ser positivas.";
    public static String identificacaoNulaEmpregado = "Identificacao do empregado nao pode ser nula.";
    public static String dataInicialMaiorQueFinal = "Data inicial nao pode ser posterior aa data final.";
}
