package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class EmpregadoNaoComissionadoException extends Exception {

    public EmpregadoNaoComissionadoException(String mensagem) {
        super(mensagem);
    }
}
