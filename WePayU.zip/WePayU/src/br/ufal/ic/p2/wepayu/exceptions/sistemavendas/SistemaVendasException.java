package br.ufal.ic.p2.wepayu.exceptions.sistemavendas;

public class SistemaVendasException extends Exception {
    public SistemaVendasException(String mensagem) {
        super(mensagem);
    }
}
