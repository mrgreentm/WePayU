package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class EmpregadoNaoEncontradoException extends Exception {
    public EmpregadoNaoEncontradoException(String mensagem) {
        super(mensagem);
    }
}
