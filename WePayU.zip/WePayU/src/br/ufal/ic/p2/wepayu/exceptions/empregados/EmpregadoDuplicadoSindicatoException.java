package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class EmpregadoDuplicadoSindicatoException extends Exception {
    public EmpregadoDuplicadoSindicatoException(String mensagem) {
        super(mensagem);
    }
}
