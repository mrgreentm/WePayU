package br.ufal.ic.p2.wepayu.exceptions.sistemasindicato;

public class TaxaSindicalNaoNumericaException extends Exception {
    public TaxaSindicalNaoNumericaException(String mensagem) {
        super(mensagem);
    }
}
