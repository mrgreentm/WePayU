package br.ufal.ic.p2.wepayu.exceptions.empregados;

public class MetodoPagamentoInvalidoException extends Exception {

    public MetodoPagamentoInvalidoException(String mensagem) {
        super(mensagem);
    }
}
